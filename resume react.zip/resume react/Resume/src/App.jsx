import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <div>
        <img src="./logo.jpg" alt="logo" className="logo" />
      </div>
      <h1>Shubham Kumar Shaw</h1>
      <div>
        <header className="resume-header">
          <div className="header-left">
            <p>
              <strong>Full Stack Developer</strong>
            </p>
            <p>
              <strong>Phone:</strong> 7488143473
            </p>
            <p>
              <strong>Location:</strong> Jamshedpur
            </p>
          </div>
          <div className="header-right">
            <p>
              Email:{" "}
              <a href="mailto:shubhamshaw930@gmail.com">
                shubhamshaw930@gmail.com
              </a>
            </p>
            <p>
              <strong>GitHub:</strong>{" "}
              <a href="https://github.com/shubhamshaw" target="_blank">
                github.com/shubhamshaw
              </a>
            </p>
            <p>
              <strong>LinkedIn:</strong>{" "}
              <a href="https://linkedin.com/in/shubhamshaw" target="_blank">
                linkedin.com/in/shubhamshaw
              </a>
            </p>
          </div>
        </header>
      </div>

      <section className="resume-section">
        <h2>Summary</h2>
        <p>
          Eager to learn new things and hard working.To enhance my professional
          skills and knowledge in an organisation which trust me with
          responsibilies and challenges.
        </p>
      </section>
      <section>
        <h2>Education</h2>
        <table class="education-table">
          <thead>
            <tr>
              <th>University/College</th>
              <th>Degree</th>
              <th>Percentage/CGPA</th>
              <th>Year</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>NIT KKR</td>
              <td>MCA</td>
              <td>9.2/10</td>
              <td>2023-26</td>
            </tr>
            <tr>
              <td>KMPM Vocational Clg</td>
              <td>BCA</td>
              <td>90%</td>
              <td>2019-22</td>
            </tr>
            <tr>
              <td>Jusco School South park</td>
              <td>Intermediate</td>
              <td>79%</td>
              <td>2019</td>
            </tr>
            <tr>
              <td>Times Scholars'Gurukul</td>
              <td>Matriculation</td>
              <td>10/10</td>
              <td>2017</td>
            </tr>
          </tbody>
        </table>
      </section>

      <section className="resume-section">
        <h2>Skills</h2>
        <ul>
          <li>JavaScript / ES6</li>
          <li>React / Redux</li>
          <li>Node.js / Express</li>
          <li>HTML / CSS</li>
          <li>SQL / MongoDB</li>
          <li>Git / GitHub</li>
        </ul>
      </section>

      <section>
        <h2>Projects</h2>
        <ul>
          <li>Movie Recommendar System - ML Prtoject</li>
          <li>Online food order System - Frontend project</li>
        </ul>
      </section>

      <section>
        <h2>Co-Curricular</h2>
        <li>Playing individual Games and Team-Oriented</li>
        <li>Exploring on Internet</li>
      </section>
    </>
  );
}

export default App;

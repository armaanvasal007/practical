const express = require("express");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 8000;

// Middleware
app.use(cookieParser());
app.use(express.json());

// CORS Setup for local testing
app.use(cors({
  origin: "http://localhost:8000",
  credentials: true,
}));

// Serve static files like index.html
app.use(express.static(path.join(__dirname, "../")));

// ✅ Moved Cookie API to /api to avoid conflict with index.html
app.get("/api", (req, res) => {
  res.cookie("userId", "1234", {
    expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7),
    secure: false,
    sameSite: "Lax",
  });

  res.cookie("sessionId", "1", {
    secure: false,
    sameSite: "Lax",
  });

  res.json({ message: "Welcome to Cookie API!" });
});

// Mobile validation route
app.post("/check-mobile", (req, res) => {
  const { mobileNumber } = req.body;
  const mobile = mobileNumber?.trim();
  const mobileRegex = /^[0-9]{10}$/;

  console.log("UserId from cookies: ", req.cookies.userId);

  if (!req.cookies.userId) {
    return res.status(401).json({ message: "Unauthorized!" });
  }

  if (!mobileRegex.test(mobile)) {
    return res.status(400).json({ message: "Mobile number is invalid!" });
  }

  res.json({ message: "Mobile number is valid!" });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
